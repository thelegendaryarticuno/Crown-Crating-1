async function searchInvoice() {
    const invoiceId = document.getElementById('invoiceId').value;
    if (!invoiceId) {
        alert('Please enter an invoice ID');
        return;
    }
    
    try {
        const response = await fetch(`http://localhost:3000/invoices/${invoiceId}`);
        if (!response.ok) {
            if (response.status === 404) {
                alert('Invoice not found');
            } else {
                alert('Error fetching invoice');
            }
            return;
        }
        const invoice = await response.json();
        displayInvoice(invoice);
    } catch (error) {
        console.error('Error fetching invoice:', error);
        alert('Error fetching invoice');
    }
}

function displayInvoice(invoice) {
    const invoiceDetails = document.getElementById('invoiceDetails');
    invoiceDetails.innerHTML = `
        <div class="invoice">
            <h2>Invoice</h2>
            <p><strong>Invoice ID:</strong> ${invoice.invoiceId}</p>
            <p><strong>Amount:</strong> $${invoice.amount.toFixed(2)}</p>
            <p><strong>Date:</strong> ${new Date(invoice.date).toLocaleDateString()}</p>
            <h3>Items:</h3>
            <ul>
                ${invoice.items.map(item => `<li>${item}</li>`).join('')}
            </ul>
            <p><strong>Payment Status:</strong> <span id="payment-status">${invoice.status}</span></p>
            <div id="paypal-button-container"></div>
        </div>
    `;

    // Load the PayPal button with the invoice amount
    loadPayPalButton(invoice.invoiceId, invoice.amount.toFixed(2));
}

function loadPayPalButton(invoiceId, amount) {
    paypal.Buttons({
        createOrder: function (data, actions) {
            return actions.order.create({
                purchase_units: [{
                    amount: {
                        value: amount
                    }
                }]
            });
        },
        onApprove: function (data, actions) {
            return actions.order.capture().then(function (details) {
                alert('Payment successful! Thank you, ' + details.payer.name.given_name);
                updatePaymentStatus(invoiceId);
            });
        }
    }).render('#paypal-button-container');
}

async function updatePaymentStatus(invoiceId) {
    try {
        const response = await fetch(`http://localhost:3000/invoices/${invoiceId}`, {
            method: 'PUT'
        });
        if (response.ok) {
            document.getElementById('payment-status').textContent = 'Completed';
        } else {
            alert('Failed to update payment status');
        }
    } catch (error) {
        console.error('Error updating payment status:', error);
        alert('Error updating payment status');
    }
}

// Load the PayPal script
const paypalScript = document.createElement('script');
paypalScript.src = 'https://www.paypal.com/sdk/js?client-id=test&currency=USD';
paypalScript.onload = () => {
    console.log('PayPal SDK loaded');
};
document.head.appendChild(paypalScript);
